#include "Obj.h"

Obj::Obj()
{
}

Obj::~Obj()
{
}
