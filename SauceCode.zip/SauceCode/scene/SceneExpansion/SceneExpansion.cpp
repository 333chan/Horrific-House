#include "SceneExpansion.h"

SceneExpansion::SceneExpansion()
{
}

SceneExpansion::~SceneExpansion()
{
}
