#include "InventoryUI.h"

InventoryUI::InventoryUI()
{
}

InventoryUI::~InventoryUI()
{
}

void InventoryUI::Init()
{
}

void InventoryUI::Update()
{
}

void InventoryUI::Draw()
{
}
